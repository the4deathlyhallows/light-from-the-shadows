param workspaceResourceId string
param alertRuleName string
param displayName string
param description string
param severity string
param query string
param tactics array = []
param techniques array = []
param queryFrequency string = 'PT1H'
param queryPeriod string = 'PT1H'
param triggerOperator string = 'GreaterThan'
param triggerThreshold int = 0

resource scheduledRule 'Microsoft.OperationalInsights/workspaces/providers/alertRules@2024-01-01-preview' = {
  name: '${last(split(workspaceResourceId, "/"))}/Microsoft.SecurityInsights/${alertRuleName}'
  properties: {
    displayName: displayName
    description: description
    enabled: true
    severity: severity
    query: query
    queryFrequency: queryFrequency
    queryPeriod: queryPeriod
    triggerOperator: triggerOperator
    triggerThreshold: triggerThreshold
    tactics: tactics
    techniques: techniques
    kind: 'Scheduled'
    eventGroupingSettings: {
      aggregationKind: 'AlertPerResult'
    }
    incidentConfiguration: {
      createIncident: true
      groupingConfiguration: {
        enabled: false
        reopenClosedIncident: false
        lookbackDuration: 'PT5H'
        matchingMethod: 'AllEntities'
        groupByEntities: []
        groupByAlertDetails: []
        groupByCustomDetails: []
      }
    }
    suppressionEnabled: false
    suppressionDuration: 'PT1H'
  }
}
